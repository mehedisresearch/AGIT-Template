# AGENTS.md (Rust workspace)

## Scope

This file applies to Rust development under `rust/`. It complements the repo root `CONTRIBUTING.md` and `rust/kcl-lib/README.md`.

## Project overview

`rust/` contains the Rust crates that power KCL and related tooling, including:
- `kcl-lib` (core language and stdlib)
- `kcl-language-server` (LSP server + VSCode extension)
- `kcl-python-bindings` (PyO3 bindings)

## Dev environment tips

- Generated stdlib docs live under `docs/kcl-std/` and are overwritten by tests; do not edit them directly.
- If Electron Playwright tests fail locally with `bad option: --remote-debugging-port=0`, run them with `env -u ELECTRON_RUN_AS_NODE ...`, for example `env -u ELECTRON_RUN_AS_NODE npm run test:e2e:desktop -- e2e/playwright/sketch-solve-edit.spec.ts --grep "constraints can be added and undone one at a time in sketch solve mode"`.

## Code style

- Format code using the nightly toolchain: `cargo +nightly fmt`.
- Follow clippy lints: `just lint`. If the git stage is clean (i.e. there aren't any unstaged changes), you can run `just lint-fix` to automatically apply most lints.
- Avoid panicking. Return Results instead. Panic in tests and debug asserts are okay.
- Avoid `unreachable!()` in `kcl-lib` paths that can be reached from user KCL or scene data. Return a `KclError` instead so unexpected inputs surface as diagnostics instead of panics.
- Avoid non-ASCII characters in comments.

## Build and test

- Many tests require an API token. If `ZOO_API_TOKEN` isn't already defined as an environment variable, ask to have the tests run with the token.
- Build the LSP (from `rust/kcl-language-server`): `npm install` then `cargo build`.
- Run KCL snapshot tests (requires a Zoo dev token):
  - `export ZOO_API_TOKEN=your-token-here`
  - `TWENTY_TWENTY=update cargo nextest run --workspace --no-fail-fast`
- Generate stdlib markdown docs (from `rust/`): `just redo-kcl-stdlib-docs`

## Simulation tests

- Create a new sim test: `just new-sim-test foo_bar` (this creates a directory for your sim test like `kcl-lib/tests/foo/`, with an empty `input.kcl` that you should put code in).
- Run/update the sim test: `just overwrite-sim-test foo_bar`
- Inspect generated outputs and check for `execution_error.snap` before committing.

## Python bindings

- Uses `maturin` (install via `pipx install maturin` or `pip install maturin`).
- Common commands: Check the `kcl-python-bindings/justfile` 

## Standard library contributions (kcl-lib)

- Add new KCL functions in `rust/kcl-lib/kcl/std` in the correct module using camel case naming.
- Add Rust implementations of functions in `rust/kcl-lib/kcl/src/std` near similar items using snake case naming.
- Add the function to the `std_fn` list in `rust/kcl-lib/src/std/mod.rs` to map between KCL and Rust.
- Provide doc comments on the KCL function with at least one example. When adding new examples in the KCL docs, you must register them in `example_tests.rs` under `const TEST_NAMES`.
- After changes, run snapshot tests and regenerate stdlib docs.

## Release notes (Rust crates)

- Bump crate versions from `rust/`: `just bump-kcl-crate-versions`.
- Publish (after PR approval): `just publish-kcl {version}` (do not include `kcl-` prefix; the `just` task adds it).
- Tags from publish trigger releases for `kcl-python-bindings` and `kcl-language-server`.
