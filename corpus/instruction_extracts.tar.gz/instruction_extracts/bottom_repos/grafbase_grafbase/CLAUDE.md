# Repository structure

- "The CLI" refers to the binary defined in `grafbase/`.
- "The gateway" refers to the binary defined in `gateway/`.

# Coding guidelines

Code MUST be clear and concise and the same applies to comments. Clear code does not need comments explaining what it does. But you may explain _why_ you're solving a problem in a particular way.

Prefer re-using existing files. For new components, avoid creating many small files.

## Rust

### Error handling

In production code, always handle `Result` and `Option` with care when you need to retrieve the value:

```rust
# propagate errors with `?`
let result = f()?;

# custom handling
match f() {
    Ok(v) => g(v),
    Err(e) => h(e)
}
```

If it can never be `None` or an error, use `expect("reason")` or `unreachable!("reason")` in a match case rather than `.unwrap()`.

### String formatting

Prefer Use modern string formatting `format!("{value}")` rather than `format!("{}", value)`.

### Logging

Do not abuse of the `info` level with logging such as `tracing::info!`, use `debug` instead.

### Lints

You may check for errors with:

```sh
cargo clippy -p <package>
```

### Tests

In test code, you may use `.unwrap()`.

Avoid test names like `test_` and prefer using terms like "can", "should", "must" or "given" to define a property/behavior the code should uphold.

Use inline snapshots with `insta` crate rather than a chain of `assert_eq!`:

```rust
insta::assert_json_snapshot!(value, @r#""#);
// or
insta::assert_snapshot!(error, @r#""#);
```

If you do want to compare to variables, import the `assert_*` variants from the `pretty_asesertions` crate.

To generate the initial snapshots, you may run the tests with the `INSTA_FORCE_PASS=1` environment variable and use `cargo insta approve` to apply all the snapshots.

You can run tests with `nextest` as follows:

```sh
cargo nextest run -p <package>
# or for a particular set of tests
cargo nextest run -p <package> <test prefix or name>
```

### Dependencies

Dependency versions must be defined in the workspace root `Cargo.toml`. Within package they must use `workspace = true`.
However, features should be set in the individual packages themselves. For example:

```toml
# crates/engine/Cargo.toml
[dependencies]
serde_json = { workspace = true, features = ["raw_value"] }

# Cargo.toml
[workspace.dependencies]
serde_json = "1"
```

## Grafbase extensions

To build a Grafbase extension, use the `grafbase` CLI instead of `cargo`. This is important, because the CLI does not only compile it (calling out to cargo), it also generates a `manifest.json` file from the contents of `extension.toml`.

## Markdown conventions

- Always use an empty line after a heading and before starting a list.
